Script for exporting data.
