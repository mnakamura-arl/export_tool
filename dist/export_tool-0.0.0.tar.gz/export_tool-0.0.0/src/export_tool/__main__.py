import argparse
import os
import sys
from datetime import datetime
import pandas as pd
from export_tool.export_tool import ExportTool

def build_dynamic_query(sensors, start_time, end_time):
    conditions = []

    if sensors:
        sensor_list = ', '.join([f"'{s}'" for s in sensors])
        conditions.append(f"sensor_id IN ({sensor_list})")

    if start_time:
        conditions.append(f"timestamp >= '{start_time}'")
    if end_time:
        conditions.append(f"timestamp <= '{end_time}'")

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    return f"SELECT * FROM sensor_data {where_clause};"

def sanitize_filename_part(s):
    return s.replace(":", "").replace(" ", "_").replace("-", "").replace("/", "")

def generate_filename(base, ext, sensors=None, use_timestamp=True):
    parts = [base]
    if sensors:
        parts.append("S_" + "_".join(sensors))
    if use_timestamp:
        parts.append(datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"))
    return f"{'_'.join(parts)}.{ext}"

def main():
    parser = argparse.ArgumentParser(description="Query and export PostgreSQL sensor data.")
    
    # Query input
    parser.add_argument("--query", help="Raw SQL query (overrides filters)")
    parser.add_argument("--sensors", nargs="+", help="Sensor IDs to include")
    parser.add_argument("--start-time", help="Start time (ISO 8601)")
    parser.add_argument("--end-time", help="End time (ISO 8601)")

    # Output control
    parser.add_argument("--format", nargs="+", choices=["csv", "json", "excel", "bufr", "grib"], default=["csv"])
    parser.add_argument("--out-dir", default=".", help="Output directory")
    parser.add_argument("--no-timestamp", action="store_true", help="Omit timestamp in output filenames")

    # DB connection
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", default=5432, type=int)
    parser.add_argument("--user", default="postgres")
    parser.add_argument("--password", default="mysecretpassword")
    parser.add_argument("--db", default="sensordata")

    args = parser.parse_args()

    # Prepare query
    query = args.query or build_dynamic_query(args.sensors, args.start_time, args.end_time)
    db_params = {
        "host": args.host,
        "port": args.port,
        "user": args.user,
        "password": args.password,
        "database": args.db,
    }

    # Ensure output directory exists
    os.makedirs(args.out_dir, exist_ok=True)

    # Query DB
    tool = ExportTool(db_params)
    df = tool.query_db(query)

    # Fallback if empty
    if df.empty:
        print("⚠️ No data returned by the query. Exiting.")
        sys.exit(0)

    # Export
    timestamp_flag = not args.no_timestamp
    sensor_ids = args.sensors or []

    def write_file(df, fmt):
        filename = generate_filename("output", fmt, sensor_ids, timestamp_flag)
        full_path = os.path.join(args.out_dir, filename)

        if fmt == "csv":
            df.to_csv(full_path, index=False)
        elif fmt == "json":
            df.to_json(full_path, orient="records", lines=True)
        elif fmt == "excel":
            df.to_excel(full_path, index=False)
        elif fmt in ("bufr", "grib"):
            # Temporarily redirect the file-based output
            orig_write_outputs = tool.write_outputs
            tool.write_outputs = lambda _df, _fmts: None  # disable original
            setattr(tool, f"_target_{fmt}_path", full_path)
            getattr(tool, f"write_{fmt}")(df)
            tool.write_outputs = orig_write_outputs

        print(f"✅ Wrote {fmt.upper()} to {full_path}")

    for fmt in args.format:
        write_file(df, fmt)

if __name__ == "__main__":
    main()
